Emoji Addon Instructions:
In unity replace the KAT texture with the replacement texture sheet provided and enable emojis addon in the app. 